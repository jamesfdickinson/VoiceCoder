module.exports = {
    aws_table_name: 'VGM',
    aws_local_config: {
      region: 'local',
      endpoint: 'http://localhost:8000'
    },
    aws_remote_config: {
      accessKeyId: 'AKIAJKHQ4MVAOLOVPK7Q',
      secretAccessKey: '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',
      region: 'us-east-1',
    }
  };