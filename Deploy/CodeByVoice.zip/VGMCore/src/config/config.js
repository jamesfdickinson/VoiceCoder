module.exports = {
    aws_table_name: 'VGM',
    aws_local_config: {
      region: 'local',
      endpoint: 'http://localhost:8000'
    },
    aws_remote_config: {
      accessKeyId: 'AKIAJRT6A4ZBNWJR3UIQ',
      secretAccessKey: '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',
      region: 'us-east-1',
    }
  };